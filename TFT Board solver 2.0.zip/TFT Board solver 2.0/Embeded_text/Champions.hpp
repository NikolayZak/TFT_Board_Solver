#ifndef CHAMPIONS_CSV_HPP
#define CHAMPIONS_CSV_HPP

extern const char* CHAMPIONS_CSV;

#endif
