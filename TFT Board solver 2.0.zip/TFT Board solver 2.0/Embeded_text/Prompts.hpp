#ifndef PROMPTS_HPP
#define PTOMPTS_HPP

extern const char* main_options;
extern const char* separator;
extern const char* goodbye;
#endif 