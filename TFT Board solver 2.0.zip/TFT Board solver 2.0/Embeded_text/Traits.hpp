#ifndef TRAITS_CSV_HPP
#define TRAITS_CSV_HPP

extern const char* TRAITS_CSV;

#endif
